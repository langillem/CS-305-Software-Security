package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/hash")
public class ChecksumController {

    private static final String UNIQUE_DATA = "Check Sum! - Michael Langille";

    @GetMapping
    public Map<String, String> generateChecksum() {
        Map<String, String> response = new HashMap<>();
        response.put("Original String", UNIQUE_DATA);

        try {
            // Generate SHA-512 checksum
            MessageDigest digest = MessageDigest.getInstance("SHA-512");
            byte[] hash = digest.digest(UNIQUE_DATA.getBytes(StandardCharsets.UTF_8));

            // Convert hash to hex
            response.put("SHA-512 Hash", bytesToHex(hash));
        } catch (NoSuchAlgorithmException e) {
            response.put("Error", "Error generating checksum: " + e.getMessage());
        }

        return response;
    }

    // Helper function to convert byte array to hexadecimal string
    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}